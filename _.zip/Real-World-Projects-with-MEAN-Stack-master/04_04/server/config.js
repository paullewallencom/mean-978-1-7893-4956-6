module.exports = {
  mongoURL: 'mongodb://localhost:27017/loginauth',
  secret: 'secret'
}